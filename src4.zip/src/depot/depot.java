/**
 * Les calculs se font ailleurs (dans Donnees ou Statistiques) :

calculerMoyenne()
calculerPrevalence()
calculerAbondance()
calculerIntensite()
regressionLineaire()
C'est clair ?

 */