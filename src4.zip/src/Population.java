
/**
 * Classe representant un ensemble de poisson avec des statistiques
 */
public class Population {

    /**
     * @autor Fall
     */
 
    //Attributs
    /**
     * Taille du poisson
     */
    private double taille;
    /**
     * Pourcentage de poisson infectée dans un groupe
     */
    private double prevalence;
    /**
     * nombre moyen de parasites par poisson tout poisson confondu 
     * infecté ou non 
     */
    private int abondance;

    /**
     * nombre moyen de parasites chez les poissons infectés uniquement  
     */
    private double intensite;


    //Constructeurs
    /**
     * le Constructeur 
     * @param taille
     * @param prevalence
     * @param abondance
     * @param intensite
     */
    public Population(double taille, double prevalence, int abondance, double intensite){

           // Validation des parametres 
    if(taille < 0){
        throw new IllegalArgumentException("La taille ne peut pas être négatif : " + taille);
    }
    if (prevalence < 0) {
        throw new IllegalArgumentException("La prevalence ne peut pas être négatif : " + prevalence);
    }

    if (abondance < 0) {
        throw new IllegalArgumentException("L'abondance ne peut être négatif : " + abondance);
    }
    if (intensite < 0) {
        throw new IllegalArgumentException("L'intensite ne peut être négatif : " + intensite);
    }
        this.taille = taille;
        this.prevalence = prevalence;
        this.abondance = abondance;
        this.intensite = intensite;
    }

    // Accesseur

    /**
     * accessibilite de l'attributs tailles
     * @return
     */
    public double getTaille(){return taille;}
    
    /**
     * accessibilite de l'attributs prevalence
     * @return
     */
    public double getPrevalence(){return prevalence;}

    /**
     * accessibilite de l'attributs Abondance
     * @return
     */
    public int getAbondance(){return abondance;}
/**
     * accessibilite de l'attributs Intensite
     * @return
     */
    public double getIntensite(){return intensite;}

    // Surcharge du methode string 
    /**Methode toString pour l'affichage
     * @return
     */

    @Override
    public String toString(){
        return String.format("taille(mm) : %.1f | prevalence : %.1f | abondance : %d | intensite : %.1f",
         getTaille(),
        getPrevalence(),
        getAbondance(),
        getIntensite()
    );
    }
    /**
     * Fontion pour tester
     * @param args
     */
    public static void main(String[] args) {
        Population population = new Population(-12, 5, 3, 17);
        System.out.println(population + "\n");
    }

}