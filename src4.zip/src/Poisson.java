import java.util.ArrayList;
import java.util.List;
import contenus.Contenu;

/**
 * @Author Fall baba
 * @version 1.0
 * cette Classe a pour but de stocker les differentes 
 * informations concernant une poisson
 * 
 */
public class Poisson {

    //Attributs 
    /**
     * L'espece du poisson
     */
    private String especes;
    /**
     * nom du poisson
     */
    private String nom;
    /**
     * Longeur du poisson
     */
    private double longueur;
    /**
     * poids du poisson
     */
    private double poids;
    /**
     * taille du poisson
     */
    private double taille;
    /**
     * tauxInfestation du poisson
     */
    private Double tauxInfestation;
    /**
     * Liste contenant les différentes partie ou contenu du poisson
     */
    List<Contenu> maContenu;

    /**
     * lecture de l'attribut espece 
     * @return
     */
    public String getEspece(){ return especes;}

    /**
     * Lecture de l'attribut Nom 
     * @return
     */
    public String getNom(){ return nom;}

   /**
    * Pour la modification de l'attribut nom 
    * @param nom
    */
    public void setNom(String nom){this.nom = nom;}
   /**
    * lecture de l'attribut longueur
    * @return
    */
    public double getLongueur(){return longueur;}
    /**
     * Modification possible de l'attribut longueur 
     * @param longueur
     */
    public void setLongueur(double longueur){this.longueur = longueur;}

    /**
     * Lecture de l'attribut poids
     * @return
     */
    public double getPoids(){return poids;}
    /**
     * modification possible de longueur
     * @param poids
     */
    public void setPoids(double poids){this.poids = poids;}

    /**
     * lecture de taille
     * @return
     */
    public double getTaille(){return taille;}
    /**
     * Modification de taille 
     * @param taille
     */
    public void setTaille(double taille){this.taille = taille;}

    /**
     * return la liste de tout les organes (contenus) du poisson 
     * @return
     */
    public List<Contenu> getContenu(){return maContenu;}
    /**
     * Ajoute un organe au poisson
     * Chaque organe avec son propre nombre de parasite 
     * par exemple: poisson.AjouterContenu(new Foie(5)) => 5 correspond au nombre de parasites 
     * @param contenu de l'organe a ajouter 
     */
     public void AjouterContenu(Contenu contenu){
        this.maContenu.add(contenu);
    }

    public void setListContenu(Contenu contenu){this.maContenu.add(contenu);}

    /**
     * le constructeur
     * @param especes
     * @param nom
     * @param longueur
     * @param poids
     * @param taille
     * 
     * On vérifie que les données ne peuvent être négatif 
     */


    public Poisson(String nom, String especes, double longueur, double poids, double taille){
        if (longueur < 0) {
        throw new IllegalArgumentException("La longueur doit être > 0 : " + longueur);
        }
        if (poids < 0) {
                throw new IllegalArgumentException("Le poids doit être > 0 : " + poids);
        }
        if (taille < 0) {
                throw new IllegalArgumentException("La taille doit être > 0 : " + taille);
        }


        this.nom = nom;
        this.especes = especes;
        this.longueur = longueur;
        this.poids = poids;
        this.taille = taille;
        maContenu   = new ArrayList<>();
    }

    @Override
    /**
     * Surcharge de la méthode toString
     */
    public String toString(){
        return String.format("[%s] Espece: %s Longueur(cm): %.1f Poids(g): %.1f Taille(cm): %.1f \n",
         getNom(),
        getEspece(),
        getLongueur(),
        getPoids(),
        getTaille());
    }
    /**
     * @param args
     */
    public static void main(String[] args) {
        Poisson newPoisson = new Poisson("cissePoisson", "sardine", 10, 20, 174);
        System.out.println(newPoisson + "\n");
    }

}