package contenus;

/**
 * @author Fall
 */
public class Muscle_Left extends Contenu{
    private double tauxInfestation;

    /**
     * @param tauxInfestation
     */
    public Muscle_Left(double tauxInfestation){
        super("Muscle_Left");
        this.tauxInfestation = tauxInfestation;
    }
   /**
    * @return
    */
    @Override
    public double tauxInfestation(){
        return tauxInfestation;
    }
    /**
     * @param args
     */
    public static void main(String[] args) {
        Contenu muscleLeft = new LAV( 30);
        System.out.println(muscleLeft + "%\n");
    }
}