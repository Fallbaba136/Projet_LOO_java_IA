package contenus;

/**
 * @author Fall
 */
public class Liver extends Contenu{
    private double tauxInfestation;

    /**
     * @param tauxInfestation
     */
    public Liver(double tauxInfestation){
        super("Liver");
        this.tauxInfestation = tauxInfestation;
    }
   
    /**
     * @return
     */
    @Override
    public double tauxInfestation(){
        return tauxInfestation;
    }
    /**
     * @param args
     */
    public static void main(String[] args) {
        Contenu Liver = new Liver( 9);
        System.out.println(Liver + "%\n");
    }
}