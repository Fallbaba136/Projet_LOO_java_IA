package contenus;

/**
 * @author Fall
 */
public class Stomach extends Contenu{
    private double tauxInfestation;

    /**
     * @param tauxInfestation
     */
    public Stomach(double tauxInfestation){
        super("Stomach");
        this.tauxInfestation = tauxInfestation;
    }
    @Override
    /**
     * @return
     */
    public double tauxInfestation(){
        return tauxInfestation;
    }
    /**
     * @param args
     */
        public static void main(String[] args) {
        Contenu stomach = new Stomach( 3.2);
        System.out.println(stomach + "%");
    }

}