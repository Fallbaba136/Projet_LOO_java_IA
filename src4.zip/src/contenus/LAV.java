package contenus;

/**
 * @author Fall
 */
public class LAV extends Contenu{
    private double tauxInfestation;

    /**
     * @param tauxInfestation
     */
    public LAV(double tauxInfestation){
        super("LAV");
        this.tauxInfestation = tauxInfestation;
    }
   
    /**
     * @return
     */
    @Override
    public double tauxInfestation(){
        return tauxInfestation;
    }
    /**
     * @param args
     */

    public static void main(String[] args) {
         Contenu lav = new LAV( 3);
        System.out.println(lav + "%\n");
    }
}