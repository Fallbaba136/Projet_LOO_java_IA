package contenus;

/**
 * @author Fall
 */
public class Muscle_Right extends Contenu{
    private double tauxInfestation;

    /**
     * @param tauxInfestation
     */
    public Muscle_Right(double tauxInfestation){
        super("Muscle_Right");
        this.tauxInfestation = tauxInfestation;
    }
   /**
    * @return
    */
    @Override
    public double tauxInfestation(){
        return tauxInfestation;
    }
    /**
     * @param args
     */
    public static void main(String[] args) {
        Contenu muscleRight = new Muscle_Right( -15);
        System.out.println(muscleRight + "%\n");
    }
}