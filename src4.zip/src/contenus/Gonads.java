package contenus;

/**
 * @author Fall
 */
public class Gonads extends Contenu{
    private double tauxInfestation;
    /**
     * @param tauxInfestation
     */
    public Gonads(double tauxInfestation){
        super("Gonads");
        this.tauxInfestation = tauxInfestation;
    }
  
    @Override
    /**
     * @return
     */
    public double tauxInfestation(){
        return tauxInfestation;
    }
    /**
     * @param args
     */
      public static void main(String[] args) {
        Contenu gonads = new Gonads( 00);
        System.out.println(gonads + "%");
    }

}